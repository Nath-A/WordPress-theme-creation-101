// ACCUEIL - LIRE LA SUITE
document.getElementById("index-lire-la-suite").addEventListener("click", lireLaSuite);

function lireLaSuite()
{
    indexSuite = document.getElementById("index-suite");
    indexSuite.style.display="block";
}