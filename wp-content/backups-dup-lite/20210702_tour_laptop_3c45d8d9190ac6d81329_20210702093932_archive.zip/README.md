# WordPress-theme-creation-101

## What!?
Let's learn and try to create a WordPress theme from scratch :muscle:
![Template Wordpress](https://developer.wordpress.org/files/2014/10/Screenshot-2019-01-23-00.20.04.png)
*You can click on the picture if you want to see the screenshot in a better quality and make the same face I did the first time I saw the... [**template hierarchy**](https://wphierarchy.com/)  (Something like :scream: )*

## How!?
By following the [Grafikart tutorial](https://www.youtube.com/watch?v=H5CIUAXi0Uk&list=PLjwdMgw5TTLWF1VV9TFWrsUTvWjtGS7Qt) AND practicing at the same time here, **step by step** ! 

## Who!?
At the moment, I am working alone on this part of our client project. But the final project is producted by the NaPaKa team, constitued by [**Pa**ulo](https://github.com/paulolvsn) and [**Ka**tinda](https://github.com/katinda) and myself.


## Why!?
Benoit Changeat is our client for the client project and he needs a WordPress site to present his coaching actity. It seems a great idea to learn to create a personal theme instead of using one already existant and toil to adapt it for what we need...
So let's challenge ourself and learn something new :+1:

## Where!?
In my messy pseudo work office in my messy appartment... Need to come back at BeCentral after "ce stupide rhume des foins des enfers" :sneezing_face: !

<!-- ## When!?
### Progress
9/37 -->
