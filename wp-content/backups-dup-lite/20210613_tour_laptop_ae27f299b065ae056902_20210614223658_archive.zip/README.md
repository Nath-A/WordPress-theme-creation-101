# WordPress-theme-creation-101

## What !?
Let's learn and try to create a WordPress theme from scratch :muscle:

## How !?
By following the [Grafikart tutorial](https://www.youtube.com/watch?v=H5CIUAXi0Uk&list=PLjwdMgw5TTLWF1VV9TFWrsUTvWjtGS7Qt) AND practicing at the same time here ! 

## Who !?
At the moment, I am working alone on this part of our client project. But the final project is producted by the NaPaKa team, constitued by [**Pa**ulo](https://github.com/paulolvsn) and [**Ka**tinda](https://github.com/katinda) and myself.


## Why !?
Benoit Changeat is our client for the client project and he needs a WordPress site to present his coaching actity. It seems a great idea to learn to create a personal theme instead of using one already existant and toil to adapt it for what we need...
So let's challenge ourself and learn something new :+1:

## Where !?
In my messy pseudo work office in my messy appartment... Need to come back at BeCentral after "ce stupide rhume des foins des enfers" :sneezing_face: !
